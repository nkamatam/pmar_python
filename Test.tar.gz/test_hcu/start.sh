for i in `cat ports.txt`
do 
cd $i
jupyter-notebook --no-browser --port=$i > ../jupyter_$i.log 2>&1 & 
cd ..
done
